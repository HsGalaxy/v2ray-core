#!/bin/bash
#
# A script to run concurrent clients and perform basic checks.
#

if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <num_clients> <duration_seconds>"
    echo "Example: $0 8 60"
    exit 1
fi

NUM_CLIENTS=$1
DURATION=$2
SERVER_IP="127.0.0.1"
CONTROL_PORT=8080
SOCKS5_PORT=1080

CLIENT_BIN="./build/reverse_tunnel_client"
SERVER_BIN="./build/reverse_tunnel_server"

# --- Pre-flight Checks ---
if [ ! -f "$SERVER_BIN" ]; then
    echo "❌ Error: Server binary '$SERVER_BIN' not found. Please run 'make server'."
    exit 1
fi
if [ ! -f "$CLIENT_BIN" ]; then
    echo "❌ Error: Client binary '$CLIENT_BIN' not found. Please run 'make client'."
    exit 1
fi

# --- Test Execution ---
echo "--- 🚀 Starting Concurrent Test ---"
echo "  Number of clients: $NUM_CLIENTS"
echo "  Test duration: $DURATION seconds"
echo "-----------------------------------"

# Start the server in the background
echo "[$(date +%T)] Starting server..."
$SERVER_BIN $CONTROL_PORT $SOCKS5_PORT 2223 > /tmp/server.log 2>&1 &
SERVER_PID=$!
# Give the server a moment to start up
sleep 2

if ! ps -p $SERVER_PID > /dev/null; then
   echo "❌ FATAL: Server failed to start. Check /tmp/server.log for details."
   exit 1
fi
echo "✅ Server is running with PID: $SERVER_PID"

# Start concurrent clients
CLIENT_PIDS=()
for i in $(seq 1 $NUM_CLIENTS); do
    DEVICE_ID="device_$(printf "%03d" $i)"
    echo "[$(date +%T)] Starting client for device: $DEVICE_ID"
    # Run client in background, redirecting output
    $CLIENT_BIN -s $SERVER_IP -p $CONTROL_PORT -i $DEVICE_ID > "/tmp/client_${DEVICE_ID}.log" 2>&1 &
    CLIENT_PIDS+=($!)
done

echo "✅ All $NUM_CLIENTS clients launched. Test will run for $DURATION seconds..."

# During the test, perform some SOCKS5 checks
# This part is for demonstration. A full implementation would need a listening service on the client side.
echo "[$(date +%T)] Performing periodic SOCKS5 checks..."
for _ in $(seq 1 $((DURATION / 10))); do
    sleep 10
    RANDOM_CLIENT_INDEX=$((RANDOM % NUM_CLIENTS + 1))
    DEVICE_ID="device_$(printf "%03d" $RANDOM_CLIENT_INDEX)"
    echo "  -> Checking SOCKS5 connectivity for $DEVICE_ID..."
    # The `-I` flag gets headers, which is a quick way to test connectivity
    # `timeout` command prevents hangs
    timeout 5 curl -s -I --socks5-hostname "${DEVICE_ID}@${SERVER_IP}:${SOCKS5_PORT}" http://example.com > /dev/null
    if [ $? -eq 0 ]; then
        echo "  ✅ SOCKS5 check for $DEVICE_ID PASSED"
    else
        echo "  ❌ SOCKS5 check for $DEVICE_ID FAILED (This is expected if data relay is not fully implemented)"
    fi
done

echo "[$(date +%T)] Test duration finished."

# --- Cleanup ---
echo "--- 🧹 Cleaning up ---"

echo "Stopping server (PID: $SERVER_PID)..."
kill $SERVER_PID
# Wait for server to terminate
wait $SERVER_PID 2>/dev/null

for pid in "${CLIENT_PIDS[@]}"; do
    if ps -p $pid > /dev/null; then
       echo "Stopping client (PID: $pid)..."
       kill $pid
    fi
done
# Wait for all background jobs to finish
wait 2>/dev/null

echo "✅ Test finished and all processes cleaned up."