#!/bin/bash
#
# A simple performance monitoring script using `iostat` and `vmstat`.
# Requires `sysstat` package to be installed (sudo apt-get install sysstat).
#

if ! command -v iostat &> /dev/null || ! command -v vmstat &> /dev/null; then
    echo "Error: 'iostat' or 'vmstat' not found."
    echo "Please install the 'sysstat' package."
    echo "On Debian/Ubuntu: sudo apt-get install sysstat"
    exit 1
fi

SERVER_PROC_NAME="reverse_tunnel_server"
CLIENT_PROC_NAME="reverse_tunnel_client"

echo "--- 📊 Performance Monitor ---"
echo "Monitoring CPU, Memory, and I/O for server and client processes."
echo "Press Ctrl+C to stop."
echo "----------------------------------------------------------------"

while true; do
    clear
    echo "Timestamp: $(date)"
    echo "----------------------------------------------------------------"
    
    echo "🧠 CPU and Memory (vmstat):"
    vmstat 1 2 | tail -n1
    echo ""

    echo "💾 Disk I/O (iostat):"
    iostat -d -k 1 2 | tail -n 3
    echo ""

    echo "⚙️ Server Process Info:"
    pgrep -a $SERVER_PROC_NAME
    ps -p $(pgrep $SERVER_PROC_NAME) -o %cpu,%mem,rss,vsz,stat,start --no-headers | sed 's/^[ ]*//'
    echo ""

    echo "⚙️ Client Process Info (Count: $(pgrep -c $CLIENT_PROC_NAME)):"
    pgrep -a $CLIENT_PROC_NAME | head -n 5
    echo "Total CPU/Mem for all clients:"
    ps -p $(pgrep $CLIENT_PROC_NAME) -o %cpu,%mem --no-headers | awk '{cpu+=$1; mem+=$2} END {print "CPU:", cpu"%", " MEM:", mem"%"}'
    
    echo "----------------------------------------------------------------"
    echo "(Updating every 5 seconds... Press Ctrl+C to stop)"
    sleep 5
done