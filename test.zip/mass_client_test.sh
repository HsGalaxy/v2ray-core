#!/bin/bash

# 批量客户端压力测试脚本
# 用于模拟大量客户端同时连接到服务器

# 配置参数
SERVER_HOST="gitea.ix.je"
SERVER_PORT="10086"
CLIENT_BINARY="./reverse_tunnel_client"
NUM_CLIENTS=100  # 默认客户端数量
CLIENT_PREFIX="test_device_"
LOG_DIR="./mass_test_logs"
STARTUP_DELAY=0.05  # 每个客户端启动间隔（秒）

# 解析命令行参数
if [ $# -ge 1 ]; then
    NUM_CLIENTS=$1
fi

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}批量客户端压力测试${NC}"
echo -e "${BLUE}========================================${NC}"
echo -e "服务器: ${GREEN}${SERVER_HOST}:${SERVER_PORT}${NC}"
echo -e "客户端数量: ${GREEN}${NUM_CLIENTS}${NC}"
echo -e "客户端前缀: ${GREEN}${CLIENT_PREFIX}${NC}"
echo -e "${BLUE}========================================${NC}"

# 检查客户端二进制文件
if [ ! -f "$CLIENT_BINARY" ]; then
    echo -e "${RED}错误: 客户端程序不存在: $CLIENT_BINARY${NC}"
    echo -e "${YELLOW}请先运行 'make client' 编译客户端${NC}"
    exit 1
fi

# 创建日志目录
mkdir -p "$LOG_DIR"
rm -f "$LOG_DIR"/*.log 2>/dev/null

# 用于存储所有客户端进程的PID
PIDS=()

# 清理函数
cleanup() {
    echo -e "\n${YELLOW}正在停止所有客户端...${NC}"
    for pid in "${PIDS[@]}"; do
        if kill -0 "$pid" 2>/dev/null; then
            kill "$pid" 2>/dev/null
        fi
    done
    
    # 等待所有进程结束
    for pid in "${PIDS[@]}"; do
        wait "$pid" 2>/dev/null
    done
    
    echo -e "${GREEN}所有客户端已停止${NC}"
    
    # 统计结果
    echo -e "\n${BLUE}========== 测试统计 ==========${NC}"
    local success_count=$(grep -l "Device registration acknowledged" "$LOG_DIR"/*.log 2>/dev/null | wc -l)
    local failed_count=$((NUM_CLIENTS - success_count))
    echo -e "成功注册: ${GREEN}${success_count}${NC}"
    echo -e "失败: ${RED}${failed_count}${NC}"
    
    # 显示失败的客户端
    if [ $failed_count -gt 0 ]; then
        echo -e "\n${YELLOW}失败的客户端:${NC}"
        for i in $(seq 0 $((NUM_CLIENTS - 1))); do
            log_file="$LOG_DIR/client_${i}.log"
            if [ -f "$log_file" ] && ! grep -q "Device registration acknowledged" "$log_file" 2>/dev/null; then
                echo -e "  ${CLIENT_PREFIX}${i}"
            fi
        done
    fi
    
    echo -e "${BLUE}==============================${NC}"
    exit 0
}

# 捕获中断信号
trap cleanup SIGINT SIGTERM

# 启动客户端
echo -e "${YELLOW}开始启动客户端...${NC}"
for i in $(seq 0 $((NUM_CLIENTS - 1))); do
    device_id="${CLIENT_PREFIX}${i}"
    log_file="$LOG_DIR/client_${i}.log"
    
    # 启动客户端并将输出重定向到日志文件
    $CLIENT_BINARY "$SERVER_HOST" "$SERVER_PORT" "$device_id" > "$log_file" 2>&1 &
    pid=$!
    PIDS+=($pid)
    
    # 显示进度
    if [ $((i % 10)) -eq 0 ]; then
        echo -e "已启动: ${GREEN}$((i + 1))/${NUM_CLIENTS}${NC} 客户端"
    fi
    
    # 短暂延迟，避免同时发起太多连接
    sleep $STARTUP_DELAY
done

echo -e "${GREEN}所有客户端已启动！${NC}"
echo -e "${YELLOW}按 Ctrl+C 停止测试${NC}"

# 监控循环
while true; do
    sleep 5
    
    # 统计活跃客户端
    active_count=0
    for pid in "${PIDS[@]}"; do
        if kill -0 "$pid" 2>/dev/null; then
            ((active_count++))
        fi
    done
    
    # 统计成功注册的客户端
    registered_count=$(grep -l "Device registration acknowledged" "$LOG_DIR"/*.log 2>/dev/null | wc -l)
    
    echo -e "\r活跃客户端: ${GREEN}${active_count}/${NUM_CLIENTS}${NC}, 已注册: ${GREEN}${registered_count}${NC}    "
    
    # 如果所有客户端都已退出，自动结束
    if [ $active_count -eq 0 ]; then
        echo -e "\n${YELLOW}所有客户端已退出${NC}"
        cleanup
    fi
done