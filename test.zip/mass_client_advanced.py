#!/usr/bin/env python3

"""
高级批量客户端测试脚本
支持更灵活的配置和实时监控
"""

import subprocess
import threading
import time
import signal
import sys
import os
import argparse
import json
from datetime import datetime
from collections import defaultdict

class MassClientTester:
    def __init__(self, server_host, server_port, num_clients, client_binary):
        self.server_host = server_host
        self.server_port = server_port
        self.num_clients = num_clients
        self.client_binary = client_binary
        self.client_prefix = "py_test_"
        self.processes = {}
        self.stats = defaultdict(int)
        self.running = True
        self.log_dir = "./mass_test_logs_py"
        
        # 创建日志目录
        os.makedirs(self.log_dir, exist_ok=True)
        
    def start_client(self, client_id):
        """启动单个客户端"""
        device_id = f"{self.client_prefix}{client_id}"
        log_file = f"{self.log_dir}/client_{client_id}.log"
        
        try:
            with open(log_file, 'w') as f:
                proc = subprocess.Popen(
                    [self.client_binary, self.server_host, str(self.server_port), device_id],
                    stdout=f,
                    stderr=subprocess.STDOUT
                )
                self.processes[client_id] = {
                    'proc': proc,
                    'device_id': device_id,
                    'start_time': time.time(),
                    'log_file': log_file
                }
                self.stats['started'] += 1
                return True
        except Exception as e:
            print(f"启动客户端 {device_id} 失败: {e}")
            self.stats['start_failed'] += 1
            return False
    
    def check_client_status(self, client_id):
        """检查客户端状态"""
        if client_id not in self.processes:
            return 'not_started'
        
        proc_info = self.processes[client_id]
        if proc_info['proc'].poll() is not None:
            # 进程已退出
            return 'exited'
        
        # 检查是否成功注册
        try:
            with open(proc_info['log_file'], 'r') as f:
                content = f.read()
                if "Device registration acknowledged" in content:
                    return 'registered'
                elif "Failed" in content or "Error" in content:
                    return 'failed'
                else:
                    return 'connecting'
        except:
            return 'unknown'
    
    def run_batch_start(self, batch_size=10, delay=0.1):
        """分批启动客户端"""
        print(f"开始分批启动 {self.num_clients} 个客户端...")
        print(f"每批: {batch_size} 个, 批间延迟: {delay}s")
        
        for i in range(0, self.num_clients, batch_size):
            if not self.running:
                break
                
            batch_end = min(i + batch_size, self.num_clients)
            threads = []
            
            # 并发启动一批客户端
            for j in range(i, batch_end):
                t = threading.Thread(target=self.start_client, args=(j,))
                threads.append(t)
                t.start()
            
            # 等待这批完成
            for t in threads:
                t.join()
            
            print(f"已启动: {batch_end}/{self.num_clients}")
            
            if batch_end < self.num_clients:
                time.sleep(delay)
    
    def monitor_loop(self):
        """监控循环"""
        print("\n开始监控...")
        last_print_time = time.time()
        
        while self.running:
            time.sleep(1)
            
            # 每5秒打印一次状态
            if time.time() - last_print_time >= 5:
                self.print_status()
                last_print_time = time.time()
    
    def print_status(self):
        """打印当前状态"""
        status_count = defaultdict(int)
        
        for client_id in range(self.num_clients):
            status = self.check_client_status(client_id)
            status_count[status] += 1
        
        # 清除当前行并打印状态
        print("\r" + " " * 100, end="\r")
        print(f"[{datetime.now().strftime('%H:%M:%S')}] "
              f"已注册: {status_count['registered']}, "
              f"连接中: {status_count['connecting']}, "
              f"已退出: {status_count['exited']}, "
              f"失败: {status_count['failed']}", end="", flush=True)
    
    def stop_all(self):
        """停止所有客户端"""
        print("\n\n正在停止所有客户端...")
        self.running = False
        
        for client_id, proc_info in self.processes.items():
            if proc_info['proc'].poll() is None:
                proc_info['proc'].terminate()
        
        # 等待所有进程结束
        for client_id, proc_info in self.processes.items():
            proc_info['proc'].wait()
        
        print("所有客户端已停止")
    
    def print_summary(self):
        """打印测试总结"""
        print("\n" + "="*50)
        print("测试总结")
        print("="*50)
        
        status_count = defaultdict(int)
        for client_id in range(self.num_clients):
            status = self.check_client_status(client_id)
            status_count[status] += 1
        
        print(f"总客户端数: {self.num_clients}")
        print(f"成功注册: {status_count['registered']}")
        print(f"连接失败: {status_count['failed']}")
        print(f"进程退出: {status_count['exited']}")
        print(f"未启动: {status_count['not_started']}")
        
        # 计算成功率
        if self.num_clients > 0:
            success_rate = (status_count['registered'] / self.num_clients) * 100
            print(f"\n成功率: {success_rate:.2f}%")
        
        # 显示失败的客户端详情
        if status_count['failed'] > 0:
            print("\n失败的客户端:")
            for client_id in range(self.num_clients):
                if self.check_client_status(client_id) == 'failed':
                    print(f"  - {self.client_prefix}{client_id}")

def signal_handler(signum, frame):
    """信号处理器"""
    global tester
    if tester:
        tester.stop_all()
        tester.print_summary()
    sys.exit(0)

def main():
    parser = argparse.ArgumentParser(description='批量客户端压力测试')
    parser.add_argument('--host', default='gitea.ix.je', help='服务器地址')
    parser.add_argument('--port', type=int, default=10086, help='服务器端口')
    parser.add_argument('--clients', type=int, default=100, help='客户端数量')
    parser.add_argument('--batch', type=int, default=10, help='每批启动的客户端数')
    parser.add_argument('--delay', type=float, default=0.1, help='批次间延迟(秒)')
    parser.add_argument('--binary', default='./build/reverse_tunnel_client', help='客户端程序路径')
    
    args = parser.parse_args()
    
    # 检查客户端程序
    if not os.path.exists(args.binary):
        print(f"错误: 客户端程序不存在: {args.binary}")
        print("请先运行 'make client' 编译客户端")
        sys.exit(1)
    
    global tester
    tester = MassClientTester(args.host, args.port, args.clients, args.binary)
    
    # 设置信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    print(f"批量客户端测试配置:")
    print(f"  服务器: {args.host}:{args.port}")
    print(f"  客户端数: {args.clients}")
    print(f"  批大小: {args.batch}")
    print(f"  批延迟: {args.delay}s")
    print("-" * 50)
    
    # 启动客户端
    start_thread = threading.Thread(
        target=tester.run_batch_start,
        args=(args.batch, args.delay)
    )
    start_thread.start()
    
    # 监控循环
    try:
        tester.monitor_loop()
    except KeyboardInterrupt:
        pass
    
    # 清理
    tester.stop_all()
    tester.print_summary()

if __name__ == "__main__":
    main()